#!/bin/sh

exec java $JAVA_OPTS -cp hazelcast-mancenter-3.12.14.war com.hazelcast.webmonitor.cli.MCConfCommandLine "$@"
